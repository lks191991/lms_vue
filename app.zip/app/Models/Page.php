<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{

    
    /**
     * Get the user's full name.
     *
     * @return string
     */
    public $table = 'pages';

}
