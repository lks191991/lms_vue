import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { TokenService } from './token.service';

@Injectable()
export class CommonService implements CanActivate {
  private baseUrl = 'http://localhost:8000/api';
  
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
    return this.Token.loggedIn();
  }
  constructor(private Token: TokenService,private http: HttpClient) { }
  
  getCourseList() {
    return this.http.get(`${this.baseUrl}/get-course-list-menu`)
  }
}